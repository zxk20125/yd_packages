"""
Allows you to use xlwings.reports instead of xlwings.pro.reports
"""

from .pro.reports import *  # noqa: F401,F403
